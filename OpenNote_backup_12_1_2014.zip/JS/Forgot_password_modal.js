
//send new password
$('#navOptionForgotPassAction').click(function() {
    
});